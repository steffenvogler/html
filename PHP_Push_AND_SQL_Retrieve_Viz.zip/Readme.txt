####TO-DO to Adapt to New Environment####

#1 UPDATE db.php

- new adress, username, and PW: mysql_connect("localhost","root","root")
- if applicable, new DB name: mysql_select_db("logging")

#2 UPDATE arduino_push_data2.php

- if applicable, new table name in line 16 and line 21: 

				mysql_query("INSERT INTO arduino_log2....  
				
				AND
				
				mysql_query("SELECT * FROM arduino_log2

#3 UPDATE SQL-Query-JSONECHO.php

- update line 3, line 4, and line 5 with new details to query the SQL
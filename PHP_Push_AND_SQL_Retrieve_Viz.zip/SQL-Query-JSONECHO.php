<?php
// Create connection
mysql_connect("localhost","root","root") or die ("Keine Verbindung moeglich");
mysql_select_db("logging") or die ("Die Datenbank existiert nicht.");
$sql = "SELECT DATE, TEMP, HUMID, LI FROM arduino_log2 ORDER BY UNIX_TIMESTAMP(DATE)";
$query = mysql_query($sql)OR die(mysql_error()); 
while($row = mysql_fetch_array($query)) {
	$result_TEMP[] = array(strtotime($row['DATE'])*1000,$row['TEMP'],);
	$result_HUMID[] = array(strtotime($row['DATE'])*1000,$row['HUMID']);
	$result_LI[] = array(strtotime($row['DATE'])*1000,$row['LI']/20);
	}
//print_r($result); 
$all_in[] = array($result_TEMP,$result_HUMID, $result_LI); 
echo json_encode($all_in, JSON_NUMERIC_CHECK);
?> 
	
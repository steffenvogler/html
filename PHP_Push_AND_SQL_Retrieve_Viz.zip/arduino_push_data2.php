<?php
// werden keine Daten per "?TEMP=......" �bergeben, wird der aktuellste Wert aus der Datenbank angezeigt
//

//Datenbank-Verbindung herstellen
//--------------------------------
include("db.php");

// GET mit Pr�fung (durch Aufruf von "http://aquarium.jleopold.de/arduino_push_data.php?TEMP=21.90&key=XXXXXXXXX")
//-----------------
if ((isset($_GET['TEMP'])) and (($_GET['key']) == "test")) {	// Wenn 'TEMP' �bergeben wurde und key stimmt...
	$TEMP = ($_GET['TEMP']);
	$HUMID = ($_GET['HUMID']);
	$LI = ($_GET['LI']);
	echo $TEMP;
	$eintragen = mysql_query("INSERT INTO arduino_log2 (TEMP,HUMID,LI,DATE)	VALUES ($TEMP,$HUMID,$LI, NOW())");	// TEMP real �bergeben, DATE = automatischer SQL-Befehl (NOW)
	
	
} else {

	$ergebnis = mysql_query("SELECT * FROM arduino_log2 ORDER BY id DESC LIMIT 1");	 //nur letzten Datensatz
	while($row = mysql_fetch_object($ergebnis))
	{
		echo "Aktuellster Wert in der Datenbank: <br><br>";
		echo "ID \t\t\t","<b>","<font color = 'red'>",$row->ID,"</b><br>";
		echo "<font color = 'black'>","Temp \t\t","<b>","<font color = 'red'>",$row->TEMP,"</b><br>";
		echo "<font color = 'black'>","Humid \t\t","<b>","<font color = 'red'>",$row->HUMID,"</b><br>";
		echo "<font color = 'black'>","Light-Intensity (approx 140 a.u. is DAY and >700 is NIGHT)  \t\t","<b>","<font color = 'red'>",$row->LI,"</b><br>";
		echo "<font color = 'black'>","Datum / Uhrzeit \t","<b>","<font color = 'red'>",$row->DATE,"</b><br>";
	}
}

?>
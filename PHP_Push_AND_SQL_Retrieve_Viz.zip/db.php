<?php
mysql_connect("localhost","root","root") or die ("Keine Verbindung moeglich");
mysql_select_db("logging") or die ("Die Datenbank existiert nicht.");
?>